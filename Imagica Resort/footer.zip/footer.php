<head>
<link href="footer.css" rel="stylesheet">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
    <footer>
     <div class="footerContainer">
        <div class="socialIcons">
            <a href=""><i class='bx bxl-twitter'></i></a>
            <a href=""><i class='bx bxl-instagram-alt'></i></a>
            <a href=""><i class='bx bxl-linkedin-square'></i></a>
            <a href=""><i class='bx bxl-facebook-square'></i></a>
            <a href=""><i class='bx bxl-youtube'></i></a>
        </div>
        <!-- <div class="footerNav">
            <ul>
                <li><a href="">HOME</a></li>
                <li><a href="">NEWS</a></li>
                <li><a href="">ABOUT</a></li>
                <li><a href="">CONTACT</a></li>
            </ul>
        </div> -->
     </div>
     <div class="footerBottom">
        <p>Copyright &copy; 2024 Imagica Resort</p>
    </div>
    </footer>
</body>
</html>